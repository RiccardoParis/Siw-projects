insert into recipe (id, name,images, description, type) values(nextval('recipe_seq'), 'Gnocchi alla sorrentina','{gnocchi_sorrentina.jpeg}','Cuocere gli gnocchi in acqua bollente fino a che non vengo a galla,unirli al sugo di pomodoro e aggiungere la mozzarella tagliata a cubetti','primo piatto');
insert into recipe (id, name,images, description, type) values(nextval('recipe_seq'), 'Pasta al forno','{pastaAlForno.jpeg}','Utilizzare della pasta già cotta precedentemente.Metterla in una teglia con mozzarella e pangrattato e lasciarla cuocere a 180 gradi per 20/30 minuti','primo piatto');
insert into recipe (id, name,images, description, type) values(nextval('recipe_seq'), 'Tiramisù','{tiramisù.jpg,tiramisù2.jpg}','Creare 3 strati di savoiardi imbevuti di caffè e crema mascarpone, il tutto decorato con una spolverata di cacao amaro','dolce');
insert into recipe (id, name,images, description, type) values(nextval('recipe_seq'), 'Polpette di patate','{PolpetteDiPatate.jpeg}','Cuocere le patate in acqua bollente, schiacciarle e unirle a pan grattato, prezzemolo,uova e parmigiano. Formare delle palline e cuocere in forno o fritte ','antipasto');
insert into recipe (id, name,images, description, type) values(nextval('recipe_seq'), 'Pesce e patate','{PesceEPatate.jpg}','Adagiare su una teglia un filetto di pesce già spinato e le patate tagliate a cubetti.Condire con olio,sale,spezie a piacere e fare cuocere a 200 gradi per 20 minuti','secondo piatto');
insert into recipe (id, name,images, description, type) values(nextval('recipe_seq'), 'Patate al forno','{patateAlForno.jpg}','Tagliare le patate a cubetti e mettere in una teglia da forno con sale,olio e rosmarino.Cuocere in forno a 180 gradi per 30 minuti','contorno');


insert into chef (id, name, surname,birth, photo) values(nextval('chef_seq'), 'Giorgio','Locatelli','1963-04-07','Giorgio_Locatelli.jpg');
insert into chef (id, name, surname,birth, photo) values(nextval('chef_seq'), 'Iginio','Massari','1942-08-29','Iginio_Massari.jpg');
insert into chef (id, name, surname,birth, photo) values(nextval('chef_seq'), 'Bruno','Barbieri','1962-01-12','Bruno_Barbieri.jpg');


insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'savoiardi','250','g'); 
insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'gnocchi','200','g');
insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'uova','2','unità');
insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'mascarpone','500','g');
insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'mozzarella','250','g');
insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'sugo di pomodoro','300','g');
insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'patate','400','g');
insert into ingredient(id,name,quantity,measure) values(nextval('ingredient_seq'),'pangrattato','150','g');