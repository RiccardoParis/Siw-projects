package it.uniroma3.siw.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.controller.validator.ChefValidator;
import it.uniroma3.siw.model.Chef;
import it.uniroma3.siw.model.Recipe;
import it.uniroma3.siw.service.ChefService;
import it.uniroma3.siw.service.RecipeService;
import jakarta.validation.Valid;

@Controller
public class ChefController {
	
	@Autowired 
	private ChefService chefService;
	
	@Autowired
	private RecipeService recipeService;
	
	@Autowired
	private ChefValidator chefValidator;
	
	@GetMapping(value="/admin/formNewChef")
	public String formNewChef(Model model) {
		model.addAttribute("chef", new Chef());
		return "admin/formNewChef.html";
	}
	
	@PostMapping("/chefs")
	public String newChef(@Valid@ModelAttribute("chef") Chef chef,BindingResult bindingResult, Model model,@RequestParam("image") MultipartFile multipartFile) throws IOException {
		this.chefValidator.validate(chef, bindingResult);
		
		if (!bindingResult.hasErrors()) {
			String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
	        chef.setPhoto(fileName);
			this.chefService.save(chef);
			String uploadDir = "chef-photo/";
			 
	        FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
			model.addAttribute("chef", chef);
			return "chef.html";
		} else {
			model.addAttribute("messaggioErrore", "Questo cuoco esiste già");
			return "admin/formNewChef.html"; 
		}
	}

	@GetMapping("/chef/{id}")
	public String getChef(@PathVariable("id") Long id, Model model) {
		model.addAttribute("chef", this.chefService.findById(id));
		return "chef.html";
	}

	@GetMapping("/chefs")
	public String getChefs(Model model) {
		model.addAttribute("chefs", this.chefService.findAll());
		return "chefs.html";
	}
	
	@GetMapping("/admin/deleteChefs")
	public String deleteChefs(Model model) {
		model.addAttribute("chefs", this.chefService.findAll());
		return "admin/deleteChefs.html";	
	}
	
	@GetMapping("/admin/chefDelete/{chefId}")
	 public String deleteById(@PathVariable("chefId") Long chefId,Model model) {
		 List<Recipe> ricette=this.recipeService.findByChef(this.chefService.findById(chefId));
		 for(Recipe ricetta:ricette) {
			 ricetta.setChef(null);
		 }
		 this.chefService.deleteById(chefId);
	    return "admin/chefDeleted.html";
	 }

}
