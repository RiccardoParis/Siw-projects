package it.uniroma3.siw.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Chef;
import it.uniroma3.siw.repository.ChefRepository;

@Service
public class ChefService{
	
	@Autowired
	private ChefRepository chefRepository;
	
	public void save(Chef chef) {
		chefRepository.save(chef);
	}
	
	public Chef findById(Long id) {
		return chefRepository.findById(id).get();
	}
	
	public List<Chef> findAll(){
		return chefRepository.findAll();
	}
	
	public void deleteById(Long id) {
		chefRepository.deleteById(id);
	}

}
