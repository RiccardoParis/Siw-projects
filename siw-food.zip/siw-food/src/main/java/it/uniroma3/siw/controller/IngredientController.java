package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Ingredient;
import it.uniroma3.siw.service.IngredientService;

@Controller
public class IngredientController {

	
	@Autowired
	private IngredientService ingredientService;
	
	
	@GetMapping(value="/formNewIngredient")
	public String formNewIngredients(Model model) {
		model.addAttribute("ingredient", new Ingredient());
		return "formNewIngredient.html";
	}
	
	@PostMapping("/ingredients")
	public String newIngredient(@ModelAttribute("ingredient") Ingredient ingredient, Model model) {
		if (!ingredientService.existsByNameAndQuantityAndMeasure(ingredient.getName(), ingredient.getQuantity(),ingredient.getMeasure())) {
			this.ingredientService.save(ingredient); 
			model.addAttribute("ingredient", ingredient);
			return "index.html";
		} else {
			model.addAttribute("messaggioErrore", "Questo ingrediente esiste già");
			return "admin/formNewIngredient.html"; 
		}
	}
	
	@GetMapping("/ingredient/{id}")
	public String getIngredient(@PathVariable("id") Long id, Model model) {
		model.addAttribute("ingredient", this.ingredientService.findById(id));
		return "ingredient.html";
	}

	@GetMapping("/ingredients")
	public String getIngredients(Model model) {
		model.addAttribute("ingredients", this.ingredientService.findAll());
		return "ingredients.html";
	}
	
	@GetMapping("/admin/deleteIngredients")
	public String deleteIngredients(Model model) {
		model.addAttribute("ingredients", this.ingredientService.findAll());
		return "admin/deleteIngredients.html";	
	}
	
	@GetMapping("/admin/ingredientDelete/{ingredientId}")
	 public String deleteById(@PathVariable("ingredientId") Long ingredientId,Model model) {
		 this.ingredientService.deleteById(ingredientId);
	    return "admin/ingredientDeleted.html";
	 }

}
