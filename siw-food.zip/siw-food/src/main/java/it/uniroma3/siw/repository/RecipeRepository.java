package it.uniroma3.siw.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Chef;
import it.uniroma3.siw.model.Recipe;



public interface RecipeRepository extends CrudRepository<Recipe,Long>{

	public List<Recipe> findByChef(Chef chef);
	
	public List<Recipe> findByName(String name);
	
	public List<Recipe> findByType(String type);

	public boolean existsByNameAndDescription(String name,String description);
	
	
	
}
