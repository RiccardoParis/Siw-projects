package it.uniroma3.siw.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
//import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.controller.validator.RecipeValidator;
import it.uniroma3.siw.model.Chef;
import it.uniroma3.siw.model.Ingredient;
//import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Recipe;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.IngredientRepository;
import it.uniroma3.siw.service.ChefService;
import it.uniroma3.siw.service.RecipeService;
import jakarta.validation.Valid;
//import it.uniroma3.siw.service.CredentialsService;
//import jakarta.validation.Valid;

@Controller
public class RecipeController {
	
	@Autowired 
	private RecipeService recipeService;
	
	@Autowired 
	private ChefService chefService;
	
	@Autowired
	private IngredientRepository ingredientRepository;
	
	@Autowired
	private GlobalController globalController;
	

	@Autowired 
	private RecipeValidator recipeValidator;
	
	//@Autowired 
	//private CredentialsService credentialsService;
	
	
	
	
	@GetMapping("/recipes")
	public String getRecipes(Model model) {
		model.addAttribute("recipes", this.recipeService.findAll());
		return "recipes.html";
	}
	
	@GetMapping("/recipe/{id}")
	public String getRecipe(@PathVariable("id") Long id, Model model) {
		model.addAttribute("recipe", this.recipeService.findById(id));
		return "recipe.html";
	}
	
	@GetMapping(value="/admin/manageRecipes")
	public String manageRecipes(Model model) {
		model.addAttribute("recipes", this.recipeService.findAll());
		return "admin/manageRecipes.html";
	}
	
	@GetMapping(value="/manageMyRecipes")
	public String manageMyRecipes(Model model) {
		List<Chef> chefs= new ArrayList<>(chefService.findAll());
	    User user= globalController.getCurrentUser();
	    Chef currentChef=null;
	    for(Chef chef:chefs) {
	    	if(chef.getName().equals(user.getName()) && chef.getSurname().equals(user.getSurname())) {
	    		currentChef=chef;
	    	}
	    }
		model.addAttribute("recipes", this.recipeService.findByChef(currentChef));
		return "manageMyRecipes.html";
	}
	
	@GetMapping(value="/admin/formUpdateRecipe/{id}")
	public String formUpdateRecipe(@PathVariable("id") Long id, Model model) {
		model.addAttribute("recipe", recipeService.findById(id));
		return "admin/formUpdateRecipe.html";
	}
	
	@GetMapping(value="/formUpdateMyRecipe/{id}")
	public String formUpdateMyRecipe(@PathVariable("id") Long id, Model model) {
		model.addAttribute("recipe", recipeService.findById(id));
		return "formUpdateMyRecipe.html";
	}
	
	@GetMapping(value="/admin/setChefToRecipe/{chefId}/{recipeId}")
	public String setChefToRecipe(@PathVariable("chefId") Long chefId, @PathVariable("recipeId") Long recipeId, Model model) {
		
		Chef cuoco = this.chefService.findById(chefId);
		Recipe recipe = this.recipeService.findById(recipeId);
		recipe.setChef(cuoco);
		this.recipeService.save(recipe);
		
		model.addAttribute("recipe", recipe);
		return "admin/formUpdateRecipe.html";
	}
	
	
	@GetMapping(value="/admin/addChef/{id}")
	public String addChef(@PathVariable("id") Long id, Model model) {
		model.addAttribute("chefs", chefService.findAll());
		model.addAttribute("recipe", recipeService.findById(id));
		return "admin/addChef.html";
	}
	
	@GetMapping(value="/formNewRecipe")
	public String formNewRecipe(Model model) {
		model.addAttribute("recipe", new Recipe());
		model.addAttribute("chefs",this.chefService.findAll());
		model.addAttribute("ingedients",this.ingredientRepository.findAll());
	    return "formNewRecipe.html";
	}
	
	@GetMapping(value="/admin/formNewRecipeAdmin")
	public String formNewRecipeAdmin(Model model) {
		model.addAttribute("recipe", new Recipe());
		model.addAttribute("chefs",this.chefService.findAll());
		model.addAttribute("ingedients",this.ingredientRepository.findAll());
	    return "/admin/formNewRecipeAdmin.html";
	}
	
	@GetMapping("/deleteRecipes")
	public String deleteRecipes(Model model) {
		model.addAttribute("recipes", this.recipeService.findAll());
		return "admin/deleteRecipes.html";	
	}
	
	@GetMapping("/deleteMyRecipes")
	public String deleteMyRecipes(Model model) {
		List<Chef> chefs= new ArrayList<>(chefService.findAll());
	    User user= globalController.getCurrentUser();
	    Chef currentChef=null;
	    for(Chef chef:chefs) {
	    	if(chef.getName().equals(user.getName()) && chef.getSurname().equals(user.getSurname())) {
	    		currentChef=chef;
	    	}
	    }
		model.addAttribute("recipes", this.recipeService.findByChef(currentChef));
		return "deleteMyRecipes.html";	
	}
	
	 @GetMapping("/recipeDelete/{recipeId}")
	 public String deleteById(@PathVariable("recipeId") Long recipeId,Model model) {
		 this.recipeService.deleteById(recipeId);
	    return "admin/recipeDeleted.html";
	 }
	
	@PostMapping("/recipes")
	public String newRecipe(@Valid@ModelAttribute("recipe") Recipe recipe,BindingResult bindingResult, Model model,@RequestParam("image") MultipartFile[] multipartFiles)throws IOException {
		this.recipeValidator.validate(recipe, bindingResult);
		if (!bindingResult.hasErrors()) {
			List<String> filenames=new ArrayList<>();
			String uploadDir = "chef-photo/";
			for(MultipartFile multipartFile:multipartFiles) {
				String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
				filenames.add(fileName);
				FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
			}
		    recipe.setImages(filenames);
		    List<Chef> chefs= new ArrayList<>(chefService.findAll());
		    User user= globalController.getCurrentUser();
		    for(Chef chef:chefs) {
		    	if(chef.getName().equals(user.getName()) && chef.getSurname().equals(user.getSurname())) {
		    		recipe.setChef(chef);
		    	}
		    }
			this.recipeService.save(recipe); 
			model.addAttribute("recipe", recipe);
			return "newRecipe.html";
		} else {
			model.addAttribute("messaggioErrore", "Questa ricetta esiste già");
			return "formNewRecipe.html"; 
		}
	}
	
	@PostMapping("/admin/recipes")
	public String newRecipeAdmin(@Valid@ModelAttribute("recipe") Recipe recipe,BindingResult bindingResult, Model model,@RequestParam("image") MultipartFile[] multipartFiles)throws IOException {
		this.recipeValidator.validate(recipe, bindingResult);
		if (!bindingResult.hasErrors()) {
			List<String> filenames=new ArrayList<>();
			String uploadDir = "chef-photo/";
			for(MultipartFile multipartFile:multipartFiles) {
				String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
				filenames.add(fileName);
				FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
			}
		    recipe.setImages(filenames);
			this.recipeService.save(recipe); 
			model.addAttribute("recipe", recipe);
			return "newRecipe.html";
		} else {
			model.addAttribute("messaggioErrore", "Questa ricetta esiste già");
			return "admin/formNewRecipeAdmin.html"; 
		}
	}
	
	@GetMapping("/updateIngredients/{id}")
	public String updateIngredients(@PathVariable("id") Long id, Model model) {

		List<Ingredient> ingredientsToAdd = this.ingredientsToAdd(id);
		model.addAttribute("ingredientsToAdd", ingredientsToAdd);
		model.addAttribute("recipe", this.recipeService.findById(id));

		return "ingredientsToAdd.html";
	}

	@GetMapping(value="/addIngredientToRecipe/{ingredientId}/{recipeId}")
	public String addIngredientToRecipe(@PathVariable("ingredientId") Long ingredientId, @PathVariable("recipeId") Long recipeId, Model model) {
		Recipe recipe = this.recipeService.findById(recipeId);
		Ingredient ingredient = this.ingredientRepository.findById(ingredientId).get();
		List<Ingredient> ingredients = recipe.getIngredients();
		ingredients.add(ingredient);
		this.recipeService.save(recipe);
		
		List<Ingredient> ingredientsToAdd = ingredientsToAdd(recipeId);
		
		model.addAttribute("recipe", recipe);
		model.addAttribute("ingredientsToAdd", ingredientsToAdd);

		return "ingredientsToAdd.html";
	}
	
	@GetMapping(value="/removeIngredientFromRecipe/{ingredientId}/{recipeId}")
	public String removeIngredientFromRecipe(@PathVariable("ingredientId") Long ingredientId, @PathVariable("recipeId") Long recipeId, Model model) {
		Recipe recipe = this.recipeService.findById(recipeId);
		Ingredient ingredient = this.ingredientRepository.findById(ingredientId).get();
		List<Ingredient> ingredients = recipe.getIngredients();
		ingredients.remove(ingredient);
		this.recipeService.save(recipe);

		List<Ingredient> ingredientsToAdd = ingredientsToAdd(recipeId);
		
		model.addAttribute("recipe", recipe);
		model.addAttribute("ingredientsToAdd", ingredientsToAdd);

		return "ingredientsToAdd.html";
	}
	

	@GetMapping("/formSearchRecipes")
	public String formSearchRecipes() {
		return "formSearchRecipes.html";
	}

	@PostMapping("/searchRecipes")
	public String searchRecipes(Model model, @RequestParam String type) {
		model.addAttribute("recipes", this.recipeService.findByType(type));
		return "foundRecipes.html";
	}
	

	private List<Ingredient> ingredientsToAdd(Long recipeId) {
		List<Ingredient> ingredientsToAdd = new ArrayList<>();

		for (Ingredient i : this.ingredientRepository.findIngredientsNotInRecipe(recipeId)) {
			ingredientsToAdd.add(i);
		}
		return ingredientsToAdd;
	}
	
	
	
	

}
