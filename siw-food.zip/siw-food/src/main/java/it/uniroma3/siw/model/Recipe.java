package it.uniroma3.siw.model;


import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Recipe {
	
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@NotBlank
	private String name;
	@Column(nullable = true, length = 64)
	private List<String> images;
	@NotBlank
	private String description;
	@NotBlank
	private String type;
	
	@ManyToMany @JsonIgnore
	private List<Ingredient> ingredients;
	
	@ManyToOne @JsonIgnore
	private Chef chef;

	public long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getImages() {
		return images;
	}
	
	public void addImage(String image) {
		this.images.add(image);
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Ingredient> getIngredients() {
		return this.ingredients;
	} 

	public void setIngredients(List<Ingredient> ingredients) {
		this.ingredients = ingredients;
	}

	public Chef getChef() {
		return chef;
	}

	public void setChef(Chef chef) {
		this.chef = chef;
	}
	
	@Transient
    public String getPhotosImagePath() {
        if (images == null ) return null;
        
        return "chef-photo/"+images.get(0);
    }
	
	@Override
	public int hashCode() {
		return Objects.hash(description, ingredients, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Recipe other = (Recipe) obj;
		return Objects.equals(description, other.description) && Objects.equals(ingredients, other.ingredients)
				&& Objects.equals(name, other.name);
	}

}
