package it.uniroma3.siw.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import it.uniroma3.siw.model.Ingredient;
import it.uniroma3.siw.repository.IngredientRepository;

@Service
public class IngredientService{
	
	@Autowired
	private IngredientRepository ingredientRepository;
	
	public void save(Ingredient ingredient) {
		ingredientRepository.save(ingredient);
	}
	
	public Ingredient findById(Long id) {
		return ingredientRepository.findById(id).get();
	}
	
	public Iterable<Ingredient> findAll(){
		return ingredientRepository.findAll();
	}
	
	public Ingredient[] findIngredientsNotInRecipe(Long recipeId) {
		return ingredientRepository.findIngredientsNotInRecipe(recipeId);
	}
	
	public boolean existsByNameAndQuantityAndMeasure(String name,int quantity,String measure) {
		return ingredientRepository.existsByNameAndQuantityAndMeasure(name, quantity,measure);
	}
	
	public void deleteById(Long id) {
		ingredientRepository.deleteById(id);
	}

}
